<?php $__env->startSection('content'); ?>
    <div class="col-lg-4">
        <div class="bs-component">
            <ul class="list-group">
                <li class="list-group-item">
                    <span class="badge">14</span>
                   София
                </li>
                <li class="list-group-item">
                    <span class="badge">2</span>
                    Варна
                </li>
                <li class="list-group-item">
                    <span class="badge">1</span>
                  Пловдив
                </li>
            </ul>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>