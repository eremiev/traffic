<?php $__env->startSection('content'); ?>
    <div class="col-lg-4">
        <div class="bs-component">
            <ul class="list-group">
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li class="list-group-item">
                        <span class="badge"> <?php echo e($city->stations); ?></span>
                        <?php echo e($city->name); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>