<?php

use App\City;
use Illuminate\Database\Seeder;

class CitySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $cities = [
            [
                'name' => 'София',
                'stations' => 20
            ],
            [
                'name' => 'Пловдив',
                'stations' => 15
            ],
            [
                'name' => 'Бургас',
                'stations' => 10
            ],
            [
                'name' => 'Варна',
                'stations' => 9
            ],
        ];

        // $this->truncate('city');

        foreach ($cities as $city) {

            City::create([
                'name' => $city['name'],
                'stations' => $city['stations']
            ]);
        }
    }
}
