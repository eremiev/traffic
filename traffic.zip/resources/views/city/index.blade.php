@extends('master')



@section('content')
    <div class="col-lg-4">
        <div class="bs-component">
            <ul class="list-group">
                @foreach($cities as $city)
                    <li class="list-group-item">
                        <span class="badge"> {{ $city->stations }}</span>
                        {{ $city->name }}
                    </li>
                @endforeach
            </ul>
        </div>

@endsection